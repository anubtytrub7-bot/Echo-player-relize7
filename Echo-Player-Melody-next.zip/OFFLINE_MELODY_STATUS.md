# Melody offline changes — status

This source update adds an offline fallback in `artifacts/echo-player/app/(tabs)/assistant.tsx`. It preserves the existing AsyncStorage chat history, answers the creator lore questions offline, and gives simple music suggestions without an API key. If a DeepSeek key is configured, the online model path remains available.

## Important limitation
This is **not yet a bundled generative language model**. The no-key/offline mode uses a small set of local rules and fallback messages; it cannot freely reason like a real LLM. A real offline LLM still needs a compatible Android native inference engine plus a bundled quantized model, then an Android build and device tests. No APK build or on-device test is claimed by this source package.

## What is preserved
- Existing Echo Player project structure and build workflow.
- Existing locally persisted chat history.
- Existing optional DeepSeek online path.
- RU/EN/KY language selection.

## Offline fallback smoke checks to perform after build
- Ask who created Melody: should mention Чубаков Эрмек and his best friend.
- Ask “как тебя забыть?”: should return the requested creator line.
- Ask what music to listen to: should offer basic mood-based suggestions.
- Send a normal unrelated question: should honestly indicate that offline mode is limited.
