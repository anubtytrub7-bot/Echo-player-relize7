const darkPalette = {
  text: "#F4F6F4", tint: "#1ED760", background: "#090B0A", foreground: "#F4F6F4",
  card: "#141816", cardForeground: "#F4F6F4", primary: "#1ED760", primaryForeground: "#07120B",
  secondary: "#1B211D", secondaryForeground: "#E8EEE9", muted: "#1B211D", mutedForeground: "#94A098",
  accent: "#1B211D", accentForeground: "#E8EEE9", destructive: "#FF6B6B", destructiveForeground: "#FFFFFF",
  border: "#242B26", input: "#242B26", heroStart: "#17392B", heroMiddle: "#111A15", heroEnd: "#101312",
  heroForeground: "#F2FFF6", heroMuted: "#A8B8AE", heroWave: "#58F79A", coverPlaceholder: "#202622", overlay: "rgba(0,0,0,0.56)",
};
const lightPalette = {
  ...darkPalette,
  text: "#172019", background: "#F5F7F5", foreground: "#172019", card: "#FFFFFF", cardForeground: "#172019",
  primary: "#168A43", primaryForeground: "#FFFFFF", secondary: "#E8EEE9", secondaryForeground: "#253329",
  muted: "#E8EEE9", mutedForeground: "#59665D", accent: "#E8EEE9", accentForeground: "#253329",
  border: "#D8E0D9", input: "#D8E0D9", heroStart: "#D6F5E0", heroMiddle: "#E9F7EE", heroEnd: "#F4FAF6",
  heroForeground: "#163522", heroMuted: "#3F654D", heroWave: "#168A43", coverPlaceholder: "#E1E8E2", overlay: "rgba(15,25,18,0.32)",
};
const colors = { light: lightPalette, dark: darkPalette, radius: 16 };
export default colors;
