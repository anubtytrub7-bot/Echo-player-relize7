import AsyncStorage from "@react-native-async-storage/async-storage";
import { setAudioModeAsync, useAudioPlayer, useAudioPlayerStatus } from "expo-audio";
import { Directory, File, Paths } from "expo-file-system";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { isTrustedApplePreviewUrl, type Track } from "./music";

const FAVORITES_KEY = "echo:favorites:v1";
const CACHED_KEY = "echo:cached:v1";

interface MusicContextValue {
  currentTrack: Track | null;
  favorites: Track[];
  cachedTracks: Track[];
  isPlaying: boolean;
  isLoading: boolean;
  currentTime: number;
  duration: number;
  playTrack: (track: Track) => void;
  togglePlayback: () => void;
  toggleFavorite: (track: Track) => void;
  cacheTrack: (track: Track) => Promise<void>;
  removeCachedTrack: (track: Track) => Promise<void>;
  seek: (time: number) => void;
}

const MusicContext = createContext<MusicContextValue | null>(null);

export function MusicProvider({ children }: { children: React.ReactNode }) {
  const player = useAudioPlayer(null, { updateInterval: 500 });
  const status = useAudioPlayerStatus(player);
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [favorites, setFavorites] = useState<Track[]>([]);
  const [cachedTracks, setCachedTracks] = useState<Track[]>([]);

  useEffect(() => {
    // Keep playback active while the app is backgrounded or the screen is locked.
    void setAudioModeAsync({
      playsInSilentMode: true,
      shouldPlayInBackground: true,
      interruptionMode: "doNotMix",
    }).catch((error) => {
      console.warn("Could not configure background audio playback", error);
    });
  }, []);

  useEffect(() => {
    void Promise.all([
      AsyncStorage.getItem(FAVORITES_KEY),
      AsyncStorage.getItem(CACHED_KEY),
    ]).then(([savedFavorites, savedCached]) => {
      if (savedFavorites) setFavorites(JSON.parse(savedFavorites) as Track[]);
      if (savedCached) setCachedTracks(JSON.parse(savedCached) as Track[]);
    }).catch(() => undefined);
  }, []);

  const playTrack = useCallback((track: Track) => {
    const saved = cachedTracks.find((item) => item.trackId === track.trackId);
    const source = saved?.localUri ?? track.previewUrl;
    if (!saved?.localUri && !isTrustedApplePreviewUrl(source)) {
      console.warn("Blocked a music preview URL outside Apple's official HTTPS domains.");
      return;
    }
    setCurrentTrack(track);
    player.setActiveForLockScreen(true, {
      title: track.trackName,
      artist: track.artistName,
      albumTitle: track.collectionName,
      artworkUrl: track.artworkUrl,
    });
    player.replace({ uri: source, name: track.trackName });
    player.play();
  }, [cachedTracks, player]);

  const togglePlayback = useCallback(() => {
    if (!currentTrack) return;
    if (status.playing) player.pause();
    else player.play();
  }, [currentTrack, player, status.playing]);

  const toggleFavorite = useCallback((track: Track) => {
    const next = favorites.some((item) => item.trackId === track.trackId)
      ? favorites.filter((item) => item.trackId !== track.trackId)
      : [track, ...favorites];
    setFavorites(next);
    void AsyncStorage.setItem(FAVORITES_KEY, JSON.stringify(next));
  }, [favorites]);

  const cacheTrack = useCallback(async (track: Track) => {
    if (!isTrustedApplePreviewUrl(track.previewUrl)) {
      throw new Error("Only HTTPS preview URLs from Apple's official catalog are allowed.");
    }
    const directory = new Directory(Paths.document, "echo-track-cache");
    directory.create({ idempotent: true, intermediates: true });
    const target = new File(directory, `${track.trackId}.m4a`);
    const downloaded = await File.downloadFileAsync(track.previewUrl, target, { idempotent: true });
    const savedTrack = { ...track, localUri: downloaded.uri };
    const next = [savedTrack, ...cachedTracks.filter((item) => item.trackId !== track.trackId)];
    setCachedTracks(next);
    await AsyncStorage.setItem(CACHED_KEY, JSON.stringify(next));
  }, [cachedTracks]);

  const removeCachedTrack = useCallback(async (track: Track) => {
    const saved = cachedTracks.find((item) => item.trackId === track.trackId);
    if (saved?.localUri) {
      try {
        new File(saved.localUri).delete();
      } catch {
        // The cache file may already have been removed by the operating system.
      }
    }
    const next = cachedTracks.filter((item) => item.trackId !== track.trackId);
    setCachedTracks(next);
    await AsyncStorage.setItem(CACHED_KEY, JSON.stringify(next));
  }, [cachedTracks]);

  const seek = useCallback((time: number) => {
    void player.seekTo(time);
  }, [player]);

  const value = useMemo<MusicContextValue>(() => ({
    currentTrack,
    favorites,
    cachedTracks,
    isPlaying: status.playing,
    isLoading: status.isBuffering,
    currentTime: status.currentTime,
    duration: status.duration,
    playTrack,
    togglePlayback,
    toggleFavorite,
    cacheTrack,
    removeCachedTrack,
    seek,
  }), [currentTrack, favorites, cachedTracks, status.playing, status.isBuffering, status.currentTime, status.duration, playTrack, togglePlayback, toggleFavorite, cacheTrack, removeCachedTrack, seek]);

  return <MusicContext.Provider value={value}>{children}</MusicContext.Provider>;
}

export function useMusic() {
  const value = useContext(MusicContext);
  if (!value) throw new Error("useMusic must be used within MusicProvider");
  return value;
}
