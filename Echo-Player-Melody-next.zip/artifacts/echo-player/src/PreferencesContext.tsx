import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

export type AppLanguage = "ru" | "en" | "ky";
export type AppTheme = "dark" | "light" | "system";

const PREFERENCES_KEY = "echo:preferences:v1";
type Preferences = { language: AppLanguage; theme: AppTheme };
type PreferencesContextValue = Preferences & {
  setLanguage: (language: AppLanguage) => void;
  setTheme: (theme: AppTheme) => void;
};
const defaults: Preferences = { language: "ru", theme: "dark" };
const PreferencesContext = createContext<PreferencesContextValue | null>(null);

export function PreferencesProvider({ children }: { children: React.ReactNode }) {
  const [preferences, setPreferences] = useState<Preferences>(defaults);

  useEffect(() => {
    let active = true;
    void AsyncStorage.getItem(PREFERENCES_KEY).then((raw) => {
      if (!active || !raw) return;
      try {
        const parsed = JSON.parse(raw) as Partial<Preferences>;
        setPreferences({
          language: parsed.language === "en" || parsed.language === "ky" ? parsed.language : "ru",
          theme: parsed.theme === "light" || parsed.theme === "system" ? parsed.theme : "dark",
        });
      } catch {
        // Ignore damaged preference data and keep safe defaults.
      }
    }).catch(() => undefined);
    return () => { active = false; };
  }, []);

  const update = useCallback((patch: Partial<Preferences>) => {
    setPreferences((current) => {
      const next = { ...current, ...patch };
      void AsyncStorage.setItem(PREFERENCES_KEY, JSON.stringify(next)).catch(() => undefined);
      return next;
    });
  }, []);

  const value = useMemo<PreferencesContextValue>(() => ({
    ...preferences,
    setLanguage: (language) => update({ language }),
    setTheme: (theme) => update({ theme }),
  }), [preferences, update]);

  return <PreferencesContext.Provider value={value}>{children}</PreferencesContext.Provider>;
}

export function usePreferences() {
  const value = useContext(PreferencesContext);
  if (!value) throw new Error("usePreferences must be used within PreferencesProvider");
  return value;
}
