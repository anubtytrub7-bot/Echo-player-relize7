export interface Track {
  trackId: number;
  trackName: string;
  artistName: string;
  collectionName: string;
  artworkUrl: string;
  previewUrl: string;
  localUri?: string;
}

interface ItunesSearchResponse {
  results?: Array<{
    trackId?: number;
    trackName?: string;
    artistName?: string;
    collectionName?: string;
    artworkUrl100?: string;
    previewUrl?: string;
  }>;
}

export function isTrustedApplePreviewUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return url.protocol === "https:" && (url.hostname === "itunes.apple.com" || url.hostname.endsWith(".itunes.apple.com"));
  } catch {
    return false;
  }
}

export async function searchTracks(term: string, limit = 25): Promise<Track[]> {
  const params = new URLSearchParams({
    term,
    media: "music",
    entity: "song",
    limit: String(limit),
    country: "KG",
  });
  const response = await fetch(`https://itunes.apple.com/search?${params.toString()}`);
  if (!response.ok) throw new Error("Music catalog unavailable");
  const payload = (await response.json()) as ItunesSearchResponse;
  return (payload.results ?? [])
    .filter((item) => item.trackId && item.trackName && item.artistName && item.previewUrl && isTrustedApplePreviewUrl(item.previewUrl) && item.artworkUrl100)
    .map((item) => ({
      trackId: item.trackId!,
      trackName: item.trackName!,
      artistName: item.artistName!,
      collectionName: item.collectionName ?? "",
      artworkUrl: item.artworkUrl100!.replace("100x100bb", "600x600bb"),
      previewUrl: item.previewUrl!,
    }));
}
