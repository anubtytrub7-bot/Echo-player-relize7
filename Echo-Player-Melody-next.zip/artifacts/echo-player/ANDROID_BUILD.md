# Build an Android APK

Replit's Expo workflow previews Android apps but does not produce a standalone APK. To build one locally, install Java and the Android SDK, then run this from the workspace root:

```sh
pnpm --filter @workspace/echo-player run build:apk
```

The command generates the Android project and builds a release APK at:

```text
artifacts/echo-player/android/app/build/outputs/apk/release/app-release.apk
```
