import { useColorScheme } from "react-native";
import colors from "@/constants/colors";
import { usePreferences } from "@/src/PreferencesContext";

export function useColors() {
  const systemScheme = useColorScheme();
  const { theme } = usePreferences();
  const scheme = theme === "system" ? systemScheme : theme;
  const palette = scheme === "light" ? colors.light : colors.dark;
  return { ...palette, radius: colors.radius };
}
