import { Feather } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import React from "react";
import { useColors } from "@/hooks/useColors";
import { usePreferences } from "@/src/PreferencesContext";
import type { AppLanguage, AppTheme } from "@/src/PreferencesContext";
import { tr } from "@/src/i18n";

export default function SettingsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { language, setLanguage, theme, setTheme } = usePreferences();
  const topPadding = Platform.OS === "web" ? 67 : insets.top + 8;
  const languages: { id: AppLanguage; label: string }[] = [
    { id: "ru", label: tr(language, "russian") },
    { id: "en", label: tr(language, "english") },
    { id: "ky", label: tr(language, "kyrgyz") },
  ];
  const themes: { id: AppTheme; label: string }[] = [
    { id: "dark", label: tr(language, "dark") },
    { id: "light", label: tr(language, "light") },
    { id: "system", label: tr(language, "system") },
  ];

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.background }} contentContainerStyle={[styles.content, { paddingTop: topPadding, paddingBottom: insets.bottom + 28 }]}>
      <View style={styles.header}>
        <View style={[styles.icon, { backgroundColor: colors.primary }]}><Feather name="sliders" size={20} color={colors.primaryForeground} /></View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.title, { color: colors.foreground }]}>{tr(language, "settingsTitle")}</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{tr(language, "settingsSubtitle")}</Text>
        </View>
      </View>

      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{tr(language, "language")}</Text>
      <View style={[styles.optionGroup, { backgroundColor: colors.card, borderColor: colors.border }]}>
        {languages.map((item) => {
          const selected = item.id === language;
          return <Pressable key={item.id} onPress={() => setLanguage(item.id)} style={[styles.option, { borderBottomColor: colors.border }]}>
            <Text style={[styles.optionText, { color: colors.foreground }]}>{item.label}</Text>
            {selected ? <Feather name="check-circle" size={19} color={colors.primary} /> : <View style={[styles.radio, { borderColor: colors.border }]} />}
          </Pressable>;
        })}
      </View>

      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{tr(language, "theme")}</Text>
      <View style={[styles.optionGroup, { backgroundColor: colors.card, borderColor: colors.border }]}>
        {themes.map((item) => {
          const selected = item.id === theme;
          return <Pressable key={item.id} onPress={() => setTheme(item.id)} style={[styles.option, { borderBottomColor: colors.border }]}>
            <View style={styles.optionLeading}>
              <Feather name={item.id === "dark" ? "moon" : item.id === "light" ? "sun" : "smartphone"} size={17} color={colors.mutedForeground} />
              <Text style={[styles.optionText, { color: colors.foreground }]}>{item.label}</Text>
            </View>
            {selected ? <Feather name="check-circle" size={19} color={colors.primary} /> : <View style={[styles.radio, { borderColor: colors.border }]} />}
          </Pressable>;
        })}
      </View>

      <View style={[styles.infoCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={styles.infoTitleRow}><Feather name="cpu" size={16} color={colors.primary} /><Text style={[styles.infoTitle, { color: colors.foreground }]}>{tr(language, "aiSettings")}</Text></View>
        <Text style={[styles.infoText, { color: colors.mutedForeground }]}>{tr(language, "apiKeyNote")}</Text>
      </View>
      <View style={[styles.infoCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={styles.infoTitleRow}><Feather name="download-cloud" size={16} color={colors.primary} /><Text style={[styles.infoTitle, { color: colors.foreground }]}>{tr(language, "offlineNote")}</Text></View>
        <Text style={[styles.infoText, { color: colors.mutedForeground }]}>{tr(language, "offlineDescription")}</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 20, gap: 12 },
  header: { flexDirection: "row", alignItems: "center", gap: 13, marginBottom: 12 },
  icon: { width: 45, height: 45, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  title: { fontSize: 27, fontWeight: "700", letterSpacing: -0.5 },
  subtitle: { fontSize: 12, marginTop: 4 },
  sectionTitle: { fontSize: 14, fontWeight: "700", marginTop: 8, marginBottom: 2 },
  optionGroup: { borderWidth: 1, borderRadius: 16, overflow: "hidden" },
  option: { minHeight: 49, paddingHorizontal: 14, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderBottomWidth: StyleSheet.hairlineWidth },
  optionLeading: { flexDirection: "row", alignItems: "center", gap: 11 },
  optionText: { fontSize: 13, fontWeight: "500" },
  radio: { width: 18, height: 18, borderWidth: 1.5, borderRadius: 9 },
  infoCard: { borderWidth: 1, borderRadius: 16, padding: 14, marginTop: 5 },
  infoTitleRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 7 },
  infoTitle: { fontSize: 13, fontWeight: "700" },
  infoText: { fontSize: 12, lineHeight: 18 },
});
