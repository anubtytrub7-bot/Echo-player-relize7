import { Feather, Ionicons } from "@expo/vector-icons";
import { useQuery } from "@tanstack/react-query";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useLocalSearchParams } from "expo-router";
import { ActivityIndicator, Alert, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import React, { useEffect, useState } from "react";
import { useColors } from "@/hooks/useColors";
import { TrackRow } from "@/src/components/TrackRow";
import { useMusic } from "@/src/MusicContext";
import { searchTracks } from "@/src/music";
import { usePreferences } from "@/src/PreferencesContext";
import { tr } from "@/src/i18n";

export default function SearchScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { language } = usePreferences();
  const quickSearches = language === "en"
    ? ["jazz", "indie", "electronic", "Bishkek"]
    : language === "ky"
      ? ["джаз", "инди", "электрондук музыка", "Бишкек"]
      : ["джаз", "инди", "электроника", "Бишкек"];
  const params = useLocalSearchParams<{ q?: string }>();
  const { playTrack, favorites, toggleFavorite, cachedTracks, cacheTrack, removeCachedTrack } = useMusic();
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [cachingId, setCachingId] = useState<number | null>(null);

  useEffect(() => {
    if (typeof params.q === "string" && params.q !== query) setQuery(params.q);
  }, [params.q]);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedQuery(query.trim()), 350);
    return () => clearTimeout(timer);
  }, [query]);

  const results = useQuery({
    queryKey: ["music-search", debouncedQuery],
    queryFn: () => searchTracks(debouncedQuery, 30),
    enabled: debouncedQuery.length > 1,
  });
  const topPadding = Platform.OS === "web" ? 67 : insets.top + 8;

  async function saveForOffline(track: Parameters<typeof cacheTrack>[0]) {
    // Apple Search API provides a short preview, not the full song. Ask before
    // saving it so the UI never implies that a full track is being downloaded.
    Alert.alert(
      tr(language, "savePreviewTitle"),
      `${tr(language, "savePreviewMessage")} (${track.trackName})`,
      [
        { text: tr(language, "cancel"), style: "cancel" },
        {
          text: tr(language, "savePreview"),
          onPress: () => {
            setCachingId(track.trackId);
            void cacheTrack(track)
              .catch(() => Alert.alert(tr(language, "saveErrorTitle"), tr(language, "saveErrorMessage")))
              .finally(() => setCachingId(null));
          },
        },
      ],
    );
  }

  return (
    <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: topPadding }]}>
      <View style={styles.header}>
        <View><Text style={[styles.kicker, { color: colors.primary }]}>{tr(language, "discover")}</Text><Text style={[styles.title, { color: colors.foreground }]}>{tr(language, "searchTitle")}</Text></View>
      </View>
      <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Feather name="search" size={19} color={colors.mutedForeground} />
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder={tr(language, "searchPlaceholder")}
          placeholderTextColor={colors.mutedForeground}
          selectionColor={colors.primary}
          autoCorrect={false}
          returnKeyType="search"
          style={[styles.input, { color: colors.foreground }]}
          testID="music-search-input"
        />
        {query ? <Pressable onPress={() => setQuery("")} accessibilityLabel={tr(language, "clearSearch")}><Ionicons name="close-circle" size={19} color={colors.mutedForeground} /></Pressable> : null}
      </View>
      {!debouncedQuery ? (
        <View style={styles.discover}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{tr(language, "trySearch")}</Text>
          <View style={styles.chips}>
            {quickSearches.map((item) => (
              <Pressable key={item} onPress={() => setQuery(item)} style={[styles.chip, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Text style={[styles.chipText, { color: colors.foreground }]}>{item}</Text>
              </Pressable>
            ))}
          </View>
          <View style={styles.empty}>
            <View style={[styles.emptyIcon, { backgroundColor: colors.card }]}><Ionicons name="disc-outline" size={25} color={colors.primary} /></View>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{tr(language, "searchEmptyTitle")}</Text>
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>{tr(language, "searchEmptyText")}</Text>
          </View>
        </View>
      ) : results.isLoading ? (
        <View style={styles.center}><ActivityIndicator color={colors.primary} /><Text style={[styles.centerText, { color: colors.mutedForeground }]}>{tr(language, "searching")} «{debouncedQuery}»…</Text></View>
      ) : results.isError ? (
        <View style={styles.center}><Text style={[styles.centerText, { color: colors.mutedForeground }]}>{tr(language, "catalogError")}</Text><Pressable onPress={() => results.refetch()} style={styles.retry}><Text style={{ color: colors.primary, fontWeight: "700" }}>{tr(language, "retry")}</Text></Pressable></View>
      ) : (
        <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: insets.bottom + 145 }} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <Text style={[styles.resultCount, { color: colors.mutedForeground }]}>{results.data?.length ?? 0} {tr(language, "results")}</Text>
          {(results.data ?? []).map((track) => {
            const cached = cachedTracks.some((item) => item.trackId === track.trackId);
            return <TrackRow key={track.trackId} track={track} favorite={favorites.some((item) => item.trackId === track.trackId)} cached={cached} busy={cachingId === track.trackId} onPlay={() => playTrack(track)} onFavorite={() => toggleFavorite(track)} onCache={() => void saveForOffline(track)} onRemoveCache={() => void removeCachedTrack(track)} />;
          })}
          {results.data?.length === 0 ? <View style={styles.noResults}><Text style={[styles.emptyTitle, { color: colors.foreground }]}>{tr(language, "noResults")}</Text><Text style={[styles.emptyText, { color: colors.mutedForeground }]}>{tr(language, "searchTryAgain")}</Text></View> : null}
          <Text style={[styles.footnote, { color: colors.mutedForeground }]}>Плеер воспроизводит короткие превью каталога.</Text>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { paddingHorizontal: 22, paddingBottom: 18 },
  kicker: { fontSize: 10, letterSpacing: 2, fontWeight: "700", marginBottom: 7 },
  title: { fontSize: 29, fontWeight: "700", letterSpacing: -0.7 },
  searchBox: { height: 52, borderWidth: 1, borderRadius: 16, marginHorizontal: 18, paddingHorizontal: 15, flexDirection: "row", alignItems: "center", gap: 11 },
  input: { flex: 1, fontSize: 14, height: "100%" },
  discover: { paddingHorizontal: 20, paddingTop: 28 },
  sectionTitle: { fontSize: 15, fontWeight: "700" },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: 9, marginTop: 14 },
  chip: { paddingHorizontal: 14, paddingVertical: 9, borderWidth: 1, borderRadius: 22 },
  chipText: { fontSize: 12, fontWeight: "600" },
  empty: { alignItems: "center", marginTop: 64, paddingHorizontal: 20 },
  emptyIcon: { width: 62, height: 62, borderRadius: 22, alignItems: "center", justifyContent: "center", marginBottom: 17 },
  emptyTitle: { fontSize: 16, fontWeight: "700", textAlign: "center" },
  emptyText: { fontSize: 13, textAlign: "center", lineHeight: 19, marginTop: 8 },
  center: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12, paddingBottom: 80 },
  centerText: { fontSize: 13 },
  retry: { padding: 10 },
  resultCount: { fontSize: 11, marginTop: 19, marginBottom: 4 },
  noResults: { alignItems: "center", paddingVertical: 54 },
  footnote: { textAlign: "center", fontSize: 10, paddingVertical: 18 },
});
