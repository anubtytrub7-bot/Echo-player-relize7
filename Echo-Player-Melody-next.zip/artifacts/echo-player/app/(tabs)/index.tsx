import { Feather, Ionicons } from "@expo/vector-icons";
import { useQuery } from "@tanstack/react-query";
import { router } from "expo-router";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ActivityIndicator, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";
import { searchTracks } from "@/src/music";
import { useMusic } from "@/src/MusicContext";
import { usePreferences } from "@/src/PreferencesContext";
import { tr } from "@/src/i18n";

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { language } = usePreferences();
  const { playTrack, favorites, toggleFavorite } = useMusic();
  const featured = useQuery({ queryKey: ["featured-tracks"], queryFn: () => searchTracks("indie pop", 12) });
  const topPadding = Platform.OS === "web" ? 67 : insets.top + 8;

  return (
    <ScrollView
      style={[styles.screen, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingTop: topPadding, paddingBottom: insets.bottom + 155 }}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <View>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>ECHO / LISTENING ROOM</Text>
          <Text style={[styles.title, { color: colors.foreground }]}>{tr(language, "homeTitle")}</Text>
        </View>
        <Pressable accessibilityLabel={tr(language, "openSearch")} onPress={() => router.push("/(tabs)/search")} style={[styles.roundButton, { backgroundColor: colors.card }]}>
          <Feather name="search" size={20} color={colors.foreground} />
        </Pressable>
      </View>

      <Pressable onPress={() => router.push("/(tabs)/assistant")} style={styles.heroWrap}>
        <LinearGradient colors={[colors.heroStart, colors.heroMiddle, colors.heroEnd]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.hero}>
          <View style={styles.heroTop}>
            <View style={styles.aiBadge}><Ionicons name="sparkles" size={13} color={colors.heroForeground} /><Text style={[styles.aiBadgeText, { color: colors.heroForeground }]}>ECHO GUIDE</Text></View>
            <Feather name="arrow-up-right" size={20} color={colors.heroForeground} />
          </View>
          <Text style={[styles.heroTitle, { color: colors.heroForeground }]}>{tr(language, "moodTitle")}</Text>
          <Text style={[styles.heroCaption, { color: colors.heroMuted }]}>{tr(language, "moodCaption")}</Text>
          <View style={styles.wave}>
            {[14, 22, 11, 30, 17, 35, 21, 12, 28, 17, 32, 13, 24, 18, 34, 12, 25].map((height, index) => (
              <View key={index} style={[styles.waveBar, { height, backgroundColor: colors.heroWave }]} />
            ))}
          </View>
        </LinearGradient>
      </Pressable>

      <View style={styles.moodSection}>
        <Text style={[styles.moodHeading, { color: colors.foreground }]}>{tr(language, "moodsTitle")}</Text>
        <View style={styles.moodChips}>
          {([
            ["moodSad", "sad indie"],
            ["moodMotivation", "motivational rock"],
            ["moodDaily", "daily pop"],
            ["moodStudy", "study instrumental"],
            ["moodWorkout", "workout electronic"],
          ] as const).map(([labelKey, term]) => (
            <Pressable key={labelKey} onPress={() => router.push({ pathname: "/(tabs)/search", params: { q: term } })} style={[styles.moodChip, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Text style={[styles.moodChipText, { color: colors.foreground }]}>{tr(language, labelKey)}</Text>
            </Pressable>
          ))}
        </View>
      </View>

      <View style={styles.sectionHeader}>
        <View><Text style={[styles.sectionTitle, { color: colors.foreground }]}>{tr(language, "featured")}</Text><Text style={[styles.subtle, { color: colors.mutedForeground }]}>{tr(language, "freshPreviews")}</Text></View>
        <Pressable onPress={() => router.push("/(tabs)/search")} accessibilityLabel={tr(language, "searchMusic")}><Feather name="arrow-right" size={19} color={colors.mutedForeground} /></Pressable>
      </View>

      {featured.isLoading ? (
        <View style={styles.loading}><ActivityIndicator color={colors.primary} /><Text style={[styles.subtle, { color: colors.mutedForeground }]}>{tr(language, "loadingTracks")}</Text></View>
      ) : featured.isError ? (
        <Pressable onPress={() => featured.refetch()} style={[styles.retry, { borderColor: colors.border }]}><Text style={{ color: colors.foreground }}>{tr(language, "catalogUnavailable")}</Text></Pressable>
      ) : (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.albumRail}>
          {(featured.data ?? []).slice(0, 8).map((track) => {
            const isFavorite = favorites.some((item) => item.trackId === track.trackId);
            return (
              <Pressable key={track.trackId} onPress={() => playTrack(track)} style={styles.albumCard}>
                <View style={styles.coverWrap}>
                  <Image source={{ uri: track.artworkUrl }} contentFit="cover" style={styles.cover} />
                  <Pressable accessibilityLabel={isFavorite ? tr(language, "removeFavorite") : tr(language, "addFavorite")} onPress={() => toggleFavorite(track)} style={styles.favoriteButton}>
                    <Ionicons name={isFavorite ? "heart" : "heart-outline"} size={17} color={isFavorite ? colors.primary : colors.foreground} />
                  </Pressable>
                  <View style={[styles.playBadge, { backgroundColor: colors.primary }]}><Ionicons name="play" size={15} color={colors.primaryForeground} /></View>
                </View>
                <Text numberOfLines={1} style={[styles.trackTitle, { color: colors.foreground }]}>{track.trackName}</Text>
                <Text numberOfLines={1} style={[styles.trackArtist, { color: colors.mutedForeground }]}>{track.artistName}</Text>
              </Pressable>
            );
          })}
        </ScrollView>
      )}

      <View style={[styles.infoRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={[styles.infoIcon, { backgroundColor: colors.primary }]}><Ionicons name="headset-outline" size={17} color={colors.primaryForeground} /></View>
        <View style={{ flex: 1 }}><Text style={[styles.infoTitle, { color: colors.foreground }]}>{tr(language, "previewOnly")}</Text><Text style={[styles.infoText, { color: colors.mutedForeground }]}>{tr(language, "previewInfo")}</Text></View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { paddingHorizontal: 22, paddingBottom: 20, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  eyebrow: { fontSize: 10, letterSpacing: 2, fontWeight: "700", marginBottom: 8 },
  title: { fontSize: 28, fontWeight: "700", letterSpacing: -0.7 },
  roundButton: { width: 44, height: 44, alignItems: "center", justifyContent: "center", borderRadius: 22 },
  heroWrap: { marginHorizontal: 18, marginBottom: 30 },
  hero: { minHeight: 198, borderRadius: 24, padding: 20, overflow: "hidden", borderWidth: 1, borderColor: "rgba(140,255,188,0.12)" },
  heroTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  aiBadge: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "rgba(31,215,105,0.15)", paddingHorizontal: 10, paddingVertical: 6, borderRadius: 20 },
  aiBadgeText: { fontSize: 10, letterSpacing: 1.3, fontWeight: "700" },
  heroTitle: { fontSize: 25, fontWeight: "700", lineHeight: 30, marginTop: 17, letterSpacing: -0.4 },
  heroCaption: { fontSize: 12, marginTop: 8 },
  wave: { position: "absolute", right: 21, bottom: 21, flexDirection: "row", alignItems: "center", gap: 4, opacity: 0.65 },
  waveBar: { width: 3, borderRadius: 4 },
  moodSection: { marginHorizontal: 20, marginBottom: 25 },
  moodHeading: { fontSize: 16, fontWeight: "700", marginBottom: 12 },
  moodChips: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  moodChip: { paddingHorizontal: 12, paddingVertical: 10, borderRadius: 20, borderWidth: 1 },
  moodChipText: { fontSize: 11, fontWeight: "600" },
  sectionHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginHorizontal: 22, marginBottom: 16 },
  sectionTitle: { fontSize: 18, fontWeight: "700", letterSpacing: -0.3 },
  subtle: { fontSize: 12, marginTop: 5 },
  loading: { minHeight: 140, alignItems: "center", justifyContent: "center", gap: 10 },
  retry: { marginHorizontal: 20, padding: 16, borderRadius: 14, borderWidth: 1 },
  albumRail: { paddingLeft: 20, paddingRight: 12, gap: 13, paddingBottom: 8 },
  albumCard: { width: 142 },
  coverWrap: { position: "relative" },
  cover: { width: 142, height: 142, borderRadius: 17 },
  favoriteButton: { position: "absolute", right: 8, top: 8, width: 32, height: 32, borderRadius: 16, alignItems: "center", justifyContent: "center" },
  playBadge: { position: "absolute", right: 8, bottom: 8, width: 32, height: 32, alignItems: "center", justifyContent: "center", borderRadius: 16 },
  trackTitle: { fontSize: 13, fontWeight: "600", marginTop: 9 },
  trackArtist: { fontSize: 12, marginTop: 3 },
  infoRow: { marginHorizontal: 20, marginTop: 20, borderWidth: 1, borderRadius: 17, padding: 14, flexDirection: "row", alignItems: "flex-start", gap: 12 },
  infoIcon: { width: 32, height: 32, alignItems: "center", justifyContent: "center", borderRadius: 11 },
  infoTitle: { fontSize: 12, fontWeight: "700", marginBottom: 4 },
  infoText: { fontSize: 11, lineHeight: 16 },
});
