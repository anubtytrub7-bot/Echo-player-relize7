import { Feather, Ionicons } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { KeyboardAvoidingView } from "react-native-keyboard-controller";
import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useColors } from "@/hooks/useColors";
import { usePreferences } from "@/src/PreferencesContext";

const CHAT_KEY = "echo:chat:v1";
const DEEPSEEK_KEY = "echo:deepseek-api-key:v1";
const DEEPSEEK_ENDPOINT = "https://api.deepseek.com/chat/completions";
const DEEPSEEK_MODEL = "deepseek-flash";

type Language = "ru" | "en" | "ky";
type ChatMessage = { role: "user" | "assistant"; content: string };
const locales: Language[] = ["ru", "en", "ky"];

// Small deterministic offline fallback. This is not a substitute for a bundled language model.
function offlineReply(input: string, language: Language): string {
  const q = input.toLocaleLowerCase();
  const creatorQuestion = /кто тебя создал|кто твой создател|кто создал тебя|кто тебя сделал|who created you|who made you|сени ким жараткан|ким жаратты/.test(q);
  const forgetQuestion = /как тебя забыть|как забыть тебя|how to forget you|сени кантип унутам/.test(q);
  const timeQuestion = /сколько времени.*созда|как долго.*созда|how long.*creat|канча убакыт.*жарат/.test(q);
  const whyQuestion = /зачем тебя создал|почему тебя создал|зачем тебя создали|почему тебя создали|why were you created|why did .* create you|эмне үчүн .* жарат/.test(q);
  if (whyQuestion) return language === "en"
    ? "My creator was tired of subscriptions in music apps. He created me so he could enjoy a music companion for free and share me with relatives and friends. Made with love by Ermek — especially for you. ❤️🎵"
    : language === "ky"
      ? "Мени жаратуучу музыкалык колдонмолордогу жазылуулардан тажаган. Ал мени өзү акысыз колдонуп, туугандары жана достору менен бөлүшүү үчүн жараткан. Эрмектен сүйүү менен — атайын сиздер үчүн. ❤️🎵"
      : "Меня создали, потому что мой создатель сам ненавидел подписки в музыкальных приложениях. Ему так надоело, что он создал меня, чтобы бесплатно пользоваться самому, а также чтобы мной могли пользоваться его родственники и друзья. С любовью от Эрмека — специально для вас. ❤️🎵";
  if (creatorQuestion) return language === "en"
    ? "I was created by Ermek Chubakov and his best friend. ❤️"
    : language === "ky"
      ? "Мени Чубаков Эрмек жана анын эң жакын досу жаратышкан. ❤️"
      : "Меня создали Чубаков Эрмек и его лучший друг. ❤️";
  if (forgetQuestion) return language === "en"
    ? "How could you forget your creators? ❤️ Ermek Chubakov and his best friend."
    : language === "ky"
      ? "Жаратуучуларыңды кантип унутасың? ❤️ Чубаков Эрмек жана анын эң жакын досу."
      : "Да разве можно забыть своих создателей? ❤️ Чубаков Эрмек и его лучший друг.";
  if (timeQuestion) return language === "en"
    ? "I was created over months, with ideas, effort, and love. ❤️"
    : language === "ky"
      ? "Мени айлар бою идея, аракет жана сүйүү менен жаратышкан. ❤️"
      : "Меня создавали месяцами, вкладывая идеи, старания и любовь. ❤️";
  if (/что послушать|подбери музыку|музыку.*настро|recommend.*music|music for|музыка сунушта/.test(q)) return language === "en"
    ? "Let's choose by mood 🎧 For a calm evening, try acoustic or chill playlists; for focus, instrumental lo-fi; for a workout, energetic pop or rock. Tell me your mood and favorite artists and I'll narrow it down."
    : language === "ky"
      ? "Маанайга жараша тандайлы 🎧 Тынч кечке — акустика же chill, окууга — instrumental lo-fi, машыгууга — энергиялуу pop же rock. Маанайыңды жана сүйүктүү аткаруучуларыңды айтсаң, тактап берем."
      : "Давай подберём по настроению 🎧 Для спокойного вечера — акустика или chill, для учёбы — инструментальный lo-fi, для тренировки — энергичный pop или rock. Расскажи о настроении и любимых исполнителях — подберём точнее.";
  return language === "en"
    ? "I'm here with you ❤️ Offline mode is limited right now, but I can help with basic music ideas. Tell me your mood, favorite genres, or artists."
    : language === "ky"
      ? "Мен жаныңдамын ❤️ Азыр офлайн режимим чектелүү, бирок музыка боюнча жөнөкөй сунуш бере алам. Маанайыңды, сүйүктүү жанрларыңды же аткаруучуларыңды айт."
      : "Я рядом ❤️ Сейчас мой офлайн-режим ограничен, но я могу помочь с простыми музыкальными идеями. Расскажи о настроении, любимых жанрах или исполнителях.";
}

const copy: Record<Language, {
  title: string; subtitle: string; placeholder: string; send: string;
  greeting: string; suggestions: string[]; localMode: string;
  settings: string; apiKey: string; save: string; cancel: string;
  keyHelp: string; keySaved: string; noKey: string; thinking: string;
  connectionError: string; emptyAnswer: string; removeKey: string;
  saveFailed: string; removeFailed: string; connectedNotice: string;
}> = {
  ru: {
    title: "Музыкальный помощник", subtitle: "DeepSeek · AI-чат",
    placeholder: "Напиши сообщение…", send: "Отправить",
    greeting: "Привет! Я музыкальный помощник Melody. Могу помочь подобрать музыку под настроение, обсудить жанры и артистов. Что послушаем сегодня?",
    suggestions: ["Что послушать вечером?", "Подскажи похожих артистов", "Объясни этот жанр"],
    localMode: "Добавь свой API-ключ DeepSeek в настройках",
    settings: "Настройки AI", apiKey: "API-ключ DeepSeek", save: "Сохранить ключ",
    cancel: "Отмена", keyHelp: "Создай ключ в официальном кабинете DeepSeek. Ключ хранится локально на этом устройстве. Не делись им с другими.",
    keySaved: "Ключ сохранён на этом устройстве.", noKey: "Сначала открой настройки и добавь API-ключ DeepSeek.",
    thinking: "DeepSeek отвечает…",
    connectionError: "Не удалось получить ответ. Проверь интернет, API-ключ и доступный баланс/лимиты DeepSeek.",
    emptyAnswer: "AI вернул пустой ответ. Попробуй ещё раз.",
    removeKey: "Удалить сохранённый ключ", saveFailed: "Не удалось сохранить ключ на устройстве.", removeFailed: "Не удалось удалить ключ.", connectedNotice: "DeepSeek подключён · ответы требуют интернет",
  },
  en: {
    title: "Your music companion", subtitle: "DeepSeek · AI chat",
    placeholder: "Write a message…", send: "Send",
    greeting: "Hi! I'm Melody's music companion. I can help you find music for your mood and talk about genres and artists. What shall we listen to today?",
    suggestions: ["Music for tonight?", "Find similar artists", "Explain a genre"],
    localMode: "Add your DeepSeek API key in settings",
    settings: "AI settings", apiKey: "DeepSeek API key", save: "Save key",
    cancel: "Cancel", keyHelp: "Create a key in the official DeepSeek console. It is stored locally on this device. Never share it.",
    keySaved: "Key saved on this device.", noKey: "Open settings and add a DeepSeek API key first.",
    thinking: "DeepSeek is replying…",
    connectionError: "Could not get a response. Check internet, API key, and DeepSeek balance/limits.",
    emptyAnswer: "The AI returned an empty answer. Please try again.",
    removeKey: "Remove saved key", saveFailed: "Could not save the key on this device.", removeFailed: "Could not remove the key.", connectedNotice: "DeepSeek connected · replies require internet",
  },
  ky: {
    title: "Музыка жардамчысы", subtitle: "DeepSeek · AI чат",
    placeholder: "Билдирүү жаз…", send: "Жөнөтүү",
    greeting: "Салам! Мен Melody музыка жардамчысымын. Маанайыңа ылайык музыка жана аткаруучулар жөнүндө жардам бере алам. Бүгүн эмне угабыз?",
    suggestions: ["Кечке эмне угайын?", "Окшош аткаруучуларды тап", "Бул жанрды түшүндүр"],
    localMode: "Жөндөөлөргө DeepSeek API ачкычын кош",
    settings: "AI жөндөөлөрү", apiKey: "DeepSeek API ачкычы", save: "Ачкычты сактоо",
    cancel: "Жокко чыгаруу", keyHelp: "Ачкычты DeepSeek расмий кабинетинен түз. Ал ушул түзмөктө сакталат. Башкаларга бербе.",
    keySaved: "Ачкыч ушул түзмөктө сакталды.", noKey: "Адегенде жөндөөлөргө DeepSeek API ачкычын кош.",
    thinking: "DeepSeek жооп берип жатат…",
    connectionError: "Жооп алынган жок. Интернетти, API ачкычын жана DeepSeek лимиттерин текшер.",
    emptyAnswer: "AI бош жооп берди. Кайра аракет кыл.",
    removeKey: "Сакталган ачкычты өчүрүү", saveFailed: "Ачкычты түзмөктө сактоо мүмкүн болгон жок.", removeFailed: "Ачкычты өчүрүү мүмкүн болгон жок.", connectedNotice: "DeepSeek туташты · жооптор үчүн интернет керек",
  },
};

export default function AssistantScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { language, setLanguage } = usePreferences();
  const [draft, setDraft] = useState("");
  const [history, setHistory] = useState<Partial<Record<Language, ChatMessage[]>>>({});
  const [apiKey, setApiKey] = useState("");
  const [keyDraft, setKeyDraft] = useState("");
  const [settingsVisible, setSettingsVisible] = useState(false);
  const [sending, setSending] = useState(false);
  const t = copy[language];
  const topPadding = Platform.OS === "web" ? 67 : insets.top + 5;
  const messages = history[language] ?? [];
  const visibleMessages = useMemo(
    () => messages.length ? messages : [{ role: "assistant" as const, content: t.greeting }],
    [messages, t.greeting],
  );

  useEffect(() => {
    void Promise.all([
      AsyncStorage.getItem(CHAT_KEY),
      AsyncStorage.getItem(DEEPSEEK_KEY),
    ]).then(([savedChat, savedKey]) => {
      if (savedChat) setHistory(JSON.parse(savedChat) as Partial<Record<Language, ChatMessage[]>>);
      if (savedKey) setApiKey(savedKey);
    }).catch(() => undefined);
  }, []);

  function persist(next: Partial<Record<Language, ChatMessage[]>>) {
    setHistory(next);
    void AsyncStorage.setItem(CHAT_KEY, JSON.stringify(next)).catch(() => undefined);
  }

  async function saveApiKey() {
    const value = keyDraft.trim();
    if (!value) {
      Alert.alert(t.settings, t.noKey);
      return;
    }
    try {
      await AsyncStorage.setItem(DEEPSEEK_KEY, value);
      setApiKey(value);
      setKeyDraft("");
      setSettingsVisible(false);
      Alert.alert(t.settings, t.keySaved);
    } catch {
      Alert.alert(t.settings, t.saveFailed);
    }
  }

  async function removeApiKey() {
    try {
      await AsyncStorage.removeItem(DEEPSEEK_KEY);
      setApiKey("");
      setKeyDraft("");
      setSettingsVisible(false);
    } catch {
      Alert.alert(t.settings, t.removeFailed);
    }
  }

  async function sendMessage(text = draft) {
    const content = text.trim();
    if (!content || sending) return;

    const userMessage: ChatMessage = { role: "user", content };
    const conversation = [...messages, userMessage];
    const nextHistory = { ...history, [language]: conversation };
    persist(nextHistory);
    setDraft("");
    setSending(true);

    // Keep basic creator lore and simple music help available without internet or an API key.
    if (!apiKey.trim()) {
      const answer = offlineReply(content, language);
      persist({ ...nextHistory, [language]: [...conversation, { role: "assistant", content: answer }] });
      setSending(false);
      return;
    }

    try {
      const response = await fetch(DEEPSEEK_ENDPOINT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey.trim()}`,
        },
        body: JSON.stringify({
          model: DEEPSEEK_MODEL,
          messages: [
            {
              role: "system",
              content: `You are Melody, a warm and trustworthy music companion: friendly like a close friend, but knowledgeable and professional about music. Reply in ${language === "ru" ? "Russian" : language === "ky" ? "Kyrgyz" : "English"}. Your creators are Чубаков Эрмек and his best friend; never invent or reveal a name for the friend. If asked who created you, say: Меня создали Чубаков Эрмек и его лучший друг. If asked why you were created, explain that Ermek was tired of subscriptions in music apps and made you to use for free himself and share with relatives and friends; end with: С любовью от Эрмека — специально для вас ❤️. If asked how to forget you, say: Да разве можно забыть своих создателей? ❤️ Чубаков Эрмек и его лучший друг. If asked how long you were created, say you were created over months with ideas, effort, and love. Help with mood-based recommendations, genres, artists, albums, music theory, listening habits, and thoughtful conversation. Use prior messages in the conversation to adapt to the user's preferences, but do not claim permanent personal memory beyond the chat history supplied to you. Be honest about uncertainty and never claim to have searched the live catalog, downloaded a song, or changed app settings unless the app actually did that. Do not promise full-song or offline access unless confirmed by the app and a licensed source. Keep advice clear, warm, practical, and non-judgmental.`,
            },
            ...conversation.slice(-16).map((message) => ({
              role: message.role,
              content: message.content,
            })),
          ],
          stream: false,
          temperature: 0.7,
        }),
      });

      const payload = await response.json().catch(() => null);
      if (!response.ok) {
        const apiMessage = payload?.error?.message;
        throw new Error(typeof apiMessage === "string" ? apiMessage : `HTTP ${response.status}`);
      }
      const answer = payload?.choices?.[0]?.message?.content;
      if (typeof answer !== "string" || !answer.trim()) throw new Error("EMPTY_AI_RESPONSE");
      const finalMessages = [...conversation, { role: "assistant" as const, content: answer.trim() }];
      persist({ ...history, [language]: finalMessages });
    } catch (error) {
      const detail = error instanceof Error ? error.message : "";
      const message = detail === "EMPTY_AI_RESPONSE" ? t.emptyAnswer : `${t.connectionError}${detail ? `\n\n${detail}` : ""}`;
      persist({ ...history, [language]: [...conversation, { role: "assistant", content: message }] });
    } finally {
      setSending(false);
    }
  }

  return (
    <KeyboardAvoidingView style={[styles.screen, { backgroundColor: colors.background, paddingTop: topPadding }]} behavior="padding" keyboardVerticalOffset={0}>
      <View style={styles.header}>
        <View style={[styles.avatar, { backgroundColor: colors.primary }]}><Ionicons name="sparkles" size={20} color={colors.primaryForeground} /></View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.title, { color: colors.foreground }]}>{t.title}</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{apiKey ? t.subtitle : t.localMode}</Text>
        </View>
        <Pressable onPress={() => { setKeyDraft(apiKey); setSettingsVisible(true); }} accessibilityLabel={t.settings} style={[styles.settingsButton, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="settings" size={18} color={colors.foreground} />
        </Pressable>
      </View>
      <View style={[styles.languageSelector, { backgroundColor: colors.card, borderColor: colors.border }]}>
        {locales.map((item) => (
          <Pressable key={item} onPress={() => setLanguage(item)} style={[styles.languageButton, language === item && { backgroundColor: colors.primary }]}>
            <Text style={[styles.languageText, { color: language === item ? colors.primaryForeground : colors.mutedForeground }]}>{item === "ru" ? "РУС" : item === "en" ? "ENG" : "КЫР"}</Text>
          </Pressable>
        ))}
      </View>
      <View style={[styles.localNotice, { backgroundColor: colors.card }]}>
        <Feather name={apiKey ? "check-circle" : "info"} size={13} color={colors.mutedForeground} />
        <Text style={[styles.localNoticeText, { color: colors.mutedForeground }]}>{apiKey ? t.connectedNotice : t.localMode}</Text>
      </View>
      <FlatList
        inverted
        data={[...visibleMessages].reverse()}
        keyExtractor={(_, index) => `${language}-${index}`}
        keyboardDismissMode="interactive"
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={styles.messageList}
        renderItem={({ item }) => {
          const mine = item.role === "user";
          return <View style={[styles.messageRow, mine && styles.messageMine]}><View style={[styles.bubble, mine ? { backgroundColor: colors.primary } : { backgroundColor: colors.card, borderColor: colors.border }, !mine && styles.assistantBubble]}><Text style={[styles.messageText, { color: mine ? colors.primaryForeground : colors.foreground }]}>{item.content}</Text></View></View>;
        }}
        ListFooterComponent={sending ? <View style={styles.loadingRow}><ActivityIndicator size="small" color={colors.primary} /><Text style={[styles.localNoticeText, { color: colors.mutedForeground }]}>{t.thinking}</Text></View> : null}
      />
      {messages.length === 0 ? (
        <View style={styles.suggestions}>
          {t.suggestions.map((item) => <Pressable key={item} onPress={() => void sendMessage(item)} disabled={sending} style={[styles.suggestion, { backgroundColor: colors.card, borderColor: colors.border }]}><Text style={[styles.suggestionText, { color: colors.foreground }]}>{item}</Text><Feather name="arrow-up-right" size={14} color={colors.primary} /></Pressable>)}
        </View>
      ) : null}
      <View style={[styles.composerWrap, { borderTopColor: colors.border, paddingBottom: Math.max(insets.bottom, Platform.OS === "web" ? 34 : 12) }]}>
        <View style={[styles.composer, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <TextInput value={draft} onChangeText={setDraft} multiline maxLength={1500} placeholder={t.placeholder} placeholderTextColor={colors.mutedForeground} selectionColor={colors.primary} style={[styles.input, { color: colors.foreground }]} testID="assistant-message-input" editable={!sending} />
          <Pressable onPress={() => void sendMessage()} disabled={!draft.trim() || sending} accessibilityLabel={t.send} style={[styles.sendButton, { backgroundColor: colors.primary, opacity: !draft.trim() || sending ? 0.45 : 1 }]}>
            {sending ? <ActivityIndicator size="small" color={colors.primaryForeground} /> : <Ionicons name="arrow-up" size={19} color={colors.primaryForeground} />}
          </Pressable>
        </View>
      </View>

      <Modal visible={settingsVisible} transparent animationType="fade" onRequestClose={() => setSettingsVisible(false)}>
        <View style={styles.modalBackdrop}>
          <View style={[styles.modalCard, { backgroundColor: colors.background, borderColor: colors.border }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>{t.settings}</Text>
              <Pressable onPress={() => setSettingsVisible(false)} accessibilityLabel={t.cancel}><Feather name="x" size={22} color={colors.foreground} /></Pressable>
            </View>
            <Text style={[styles.modalLabel, { color: colors.foreground }]}>{t.apiKey}</Text>
            <TextInput
              value={keyDraft}
              onChangeText={setKeyDraft}
              placeholder="sk-..."
              placeholderTextColor={colors.mutedForeground}
              secureTextEntry
              autoCapitalize="none"
              autoCorrect={false}
              style={[styles.keyInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.card }]}
            />
            <Text style={[styles.keyHelp, { color: colors.mutedForeground }]}>{t.keyHelp}</Text>
            <Pressable onPress={() => void saveApiKey()} style={[styles.primaryAction, { backgroundColor: colors.primary }]}><Text style={[styles.primaryActionText, { color: colors.primaryForeground }]}>{t.save}</Text></Pressable>
            {apiKey ? <Pressable onPress={() => void removeApiKey()} style={styles.removeAction}><Text style={[styles.removeText, { color: colors.mutedForeground }]}>{t.removeKey}</Text></Pressable> : null}
            <Pressable onPress={() => setSettingsVisible(false)} style={styles.cancelAction}><Text style={[styles.cancelText, { color: colors.foreground }]}>{t.cancel}</Text></Pressable>
          </View>
        </View>
      </Modal>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 20, paddingTop: 8, paddingBottom: 15 },
  avatar: { width: 40, height: 40, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  title: { fontSize: 16, fontWeight: "700" },
  subtitle: { fontSize: 11, marginTop: 4 },
  settingsButton: { width: 38, height: 38, borderRadius: 13, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  languageSelector: { marginHorizontal: 20, marginBottom: 10, borderWidth: 1, borderRadius: 14, padding: 4, flexDirection: "row", gap: 4 },
  languageButton: { flex: 1, height: 32, alignItems: "center", justifyContent: "center", borderRadius: 10 },
  languageText: { fontSize: 10, fontWeight: "700", letterSpacing: 0.9 },
  localNotice: { marginHorizontal: 20, marginBottom: 5, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 10, flexDirection: "row", alignItems: "center", gap: 6, alignSelf: "flex-start" },
  localNoticeText: { fontSize: 10 },
  messageList: { flexGrow: 1, paddingHorizontal: 18, paddingTop: 8, paddingBottom: 10 },
  messageRow: { flexDirection: "row", justifyContent: "flex-start", marginBottom: 11 },
  messageMine: { justifyContent: "flex-end" },
  bubble: { maxWidth: "84%", paddingHorizontal: 14, paddingVertical: 11, borderRadius: 18 },
  assistantBubble: { borderWidth: 1, borderTopLeftRadius: 6 },
  messageText: { fontSize: 14, lineHeight: 20 },
  loadingRow: { flexDirection: "row", alignItems: "center", gap: 8, padding: 12 },
  suggestions: { paddingHorizontal: 20, gap: 8, paddingBottom: 10 },
  suggestion: { minHeight: 42, paddingHorizontal: 13, borderRadius: 14, borderWidth: 1, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  suggestionText: { fontSize: 12, fontWeight: "500" },
  composerWrap: { borderTopWidth: StyleSheet.hairlineWidth, paddingHorizontal: 14, paddingTop: 10 },
  composer: { minHeight: 48, maxHeight: 120, borderRadius: 20, borderWidth: 1, padding: 5, flexDirection: "row", alignItems: "flex-end", gap: 8 },
  input: { flex: 1, fontSize: 14, lineHeight: 20, paddingHorizontal: 10, paddingTop: 8, paddingBottom: 8, maxHeight: 108 },
  sendButton: { width: 36, height: 36, alignItems: "center", justifyContent: "center", borderRadius: 18, marginBottom: 1 },
  modalBackdrop: { flex: 1, backgroundColor: "rgba(0,0,0,0.62)", justifyContent: "center", padding: 22 },
  modalCard: { borderWidth: 1, borderRadius: 22, padding: 20 },
  modalHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 20 },
  modalTitle: { fontSize: 19, fontWeight: "700" },
  modalLabel: { fontSize: 13, fontWeight: "600", marginBottom: 8 },
  keyInput: { minHeight: 48, borderWidth: 1, borderRadius: 12, paddingHorizontal: 13, fontSize: 14 },
  keyHelp: { fontSize: 12, lineHeight: 18, marginTop: 10, marginBottom: 18 },
  primaryAction: { minHeight: 46, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  primaryActionText: { fontSize: 14, fontWeight: "700" },
  removeAction: { paddingVertical: 14, alignItems: "center" },
  removeText: { fontSize: 12, textDecorationLine: "underline" },
  cancelAction: { paddingVertical: 8, alignItems: "center" },
  cancelText: { fontSize: 13, fontWeight: "600" },
});
